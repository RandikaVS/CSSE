<div class="container-fluid sb2">
    <div class="row">
        <div class="sb2-1">
            <!--== USER INFO ==-->
            <div class="sb2-12">
                <ul>
                    <li><img src="images/placeholder.jpg" alt="">
                    </li>
                    <li>
                        <h5>D.M.Dinesh Gamage <span> Line Manager</span></h5>
                    </li>
                    <li></li>
                </ul>
            </div>
            <!--== LEFT MENU ==-->
            <div class="sb2-13">
                <ul class="collapsible" data-collapsible="accordion">
                    <li><a href="#" class="menu-active"><i class="fa fa-bar-chart" aria-hidden="true"></i> Dashboard</a>
                    </li>
                    <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-list-ul" aria-hidden="true"></i> Manage Purchase Orders</a>
                        <div class="collapsible-body left-sub-menu">
                            <ul>
                                <li><a href="./add-purchase-order.php">Create</a>
                                </li>
                                <li><a href="./all-purchase-order.php">View</a>
                                </li>

                                </li>
                            </ul>
                        </div>
                    </li>
                    <li><a href="#" class="collapsible-header"><i class="fa fa-list-ul" aria-hidden="true"></i>Manage Employees</a></li>

                    <li><a href="#" class=""><i class="fa fa-user" aria-hidden="true"></i> Manage Suppliers</a></li>

                    <li><a href="#" class=""><i class="fa fa-user" aria-hidden="true"></i> Manage Sites</a></li>

                    <li><a href="#" class=""><i class="fa fa-user" aria-hidden="true"></i> Manage Material</a></li>




                    </li>

                </ul>
            </div>
        </div>


    </div>
</div>